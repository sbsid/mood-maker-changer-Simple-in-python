
import time
import signal
import os
try:
    # Python2
    import Tkinter as tk
except ImportError:
    # Python3
    import tkinter as tk
# get a series of gif images you have in the working folder
# or use full path name
image_files = [
'imges_anxious/1.gif',
'imges_anxious/2.gif',
'imges_anxious/3.gif',
'imges_anxious/4.gif',
'imges_anxious/5.gif',
'imges_anxious/6.gif','imges_anxious/7.gif', 'imges_anxious/8.gif'
]
root = tk.Tk()
label = tk.Label(root)
label.grid()
delay = 3.2  # seconds delay between slides
for image in image_files:
    image_object = tk.PhotoImage(file=image)
    label.config(image=image_object)
    root.title(image)
    root.update()
    time.sleep(delay)


os.kill(os.getpid(),signal.SIGILL)
root.mainloop()