from pyglet.window import mouse
import button as button
from PIL import ImageTk
import webbrowser
import pyglet
from pyglet.window import mouse
from tkinter import *
from tkinter import ttk
import time
import tkinter as tk
#import music_p
import os
from mutagen.easyid3 import EasyID3
import pygame
from tkinter.filedialog import *

root = Tk()
root.title("Moodie My Buddy")
root.geometry('560x270')
root.configure(background='bisque')

#all frames declared here
fst_frame= Frame(root,width=670, height=470, background="bisque" ,borderwidth=3)
fst_frame.grid(row=0,column=0,padx=10,pady=10)
whats_your_mood_frame = Frame(root,width=670, height=470, background="bisque" ,borderwidth=3)
happy_mood_frame = Frame(root,width=900, height=470,background="bisque")
music_player_frame = Frame(root,width=700, height=470,background="bisque" ,borderwidth=3)
anx_frame = Frame(root,background="bisque")
anx_frame.pack_propagate(0)
tired_frame = Frame(root,width=700, height=470,background="bisque" ,borderwidth=3)

sad_frame = Frame(root,width=700, height=470,background="bisque" ,borderwidth=3)
# methods

def back():
    happy_mood_frame.grid_forget()
    whats_your_mood_frame.grid(row=0,column=0,padx=10,pady=10)

def back_anx():
    anx_frame.grid_forget()
    whats_your_mood_frame.grid(row=0,column=0,padx=10,pady=10)

def slide_show():
    if __name__ == "__main__":
        os.system('slide_show.py')


def anxious_me():
    whats_your_mood_frame.grid_forget()
    anx_frame.grid(row=0,column=0,padx=10,pady=10)
    label_1 = Label(anx_frame,text="Dont be anxious \n Let ME give you some advice \n may be that will help you ",font=('MV Boli',15,'bold'))
    label_1.grid(row=2,column=2,padx=10,pady=5)
    button_1 = Button(anx_frame,text="CLICK ME!!!",command=slide_show)
    button_1.grid(row=5,column=2)
    button_2 = Button(anx_frame,text="BACK",command=back_anx)
    button_2.grid(row=0,column=2)

def happy_mood():


    whats_your_mood_frame.grid_forget()
    happy_mood_frame.grid(row=0,column=0,padx=10,pady=10)
    music_label = Label(happy_mood_frame,text="Playing music for you",font=('Arial Black',10,'italic'),background='bisque')
    music_label.grid(row=6,column=0)
    back_button = Button(happy_mood_frame,text="Back <-",command=back)
    back_button.grid(row=7,column=0)

    pygame.init()
    if __name__ == "__main__":
        os.system('music_p.py')

def pacman():
    if __name__ == "__main__":
        os.system('pacman_game.py')

def back_sad():
    sad_frame.grid_forget()
    whats_your_mood_frame.grid(row=0, column=0, padx=10, pady=10)

def COLOR():
    if __name__ == "__main__":
        os.system('typer.py')


def sad_mood():
    whats_your_mood_frame.grid_forget()
    sad_frame.grid(row=0,column=0)
    labels_1 = Label(sad_frame,text="\n Let's Try SOMETHINGS to make \n YOU\n HAPPY ",font=('MV Boli',15,'bold'))
    labels_1.grid(row=2,column=2,padx=20,pady=20)
    labels_2 = Label(sad_frame,text="Wanna Play a game \n PACMAN\n OR \n COLORGAME ",font=('MV Boli',12,'bold'))
    labels_2.grid(row=3,column=2,padx=20,pady=10)
    buu = Button(sad_frame,text="PACMAN",command=pacman)
    buu.grid(row=4,column=2)
    buu1 = Button(sad_frame, text="COLOR GAME", command=COLOR)
    buu1.grid(row=5, column=2)

    back_b = Button(sad_frame,text="<---BACK",command=back_sad)
    back_b.grid(row=0,column=2,padx=5,pady=10)

def sleep_play():
    if __name__ == "__main__":
        os.system('sleep.py')

def back_tired():
    tired_frame.grid_forget()
    whats_your_mood_frame.grid(row=0, column=0, padx=10, pady=10)

def open_browser():
    webbrowser.open_new_tab("https://medium.com/personal-growth-lab/8-habits-to-stop-feeling-tired-generate-unstoppable-energy-instead-441b6c13e4df")


def tired_func():
    whats_your_mood_frame.grid_forget()
    tired_frame.grid(row=0,column=0,padx=5,pady=5)
    t_label1 = Label(tired_frame,text="Wanna take a NAP \n Should I play some music for you ",font=('MV Boli',12,'bold'))
    t_label1.grid(row=2,column=2,padx=20,pady=20)
    t_button = Button(tired_frame,text="PLAY",command=sleep_play)
    t_button.grid(row=3,column=2,padx=10,pady=10)
    t_back = Button(tired_frame,text="<----BACK",command=back_tired)
    t_back.grid(row=1,column=2,padx=10,pady=10)
    t_label2 = Label(tired_frame, text="Or need some more Ideas\n Click on MORE  ",
                     font=('MV Boli', 15, 'bold'))
    t_label2.grid(row=4, column=2, padx=20, pady=20)
    t_button2 = Button(tired_frame, text="MORE", command=open_browser)
    t_button2.grid(row=5, column=2, padx=10, pady=10)


def whats_your_mood():
    root.geometry('400x370')
    fst_frame.grid_forget()
    whats_your_mood_frame.grid(row=0, column=0, padx=10, pady=10)
    label = ttk.Label(whats_your_mood_frame,text="Tell us your mood ",font=("Arial Black",14,'italic'), background="bisque")
    label.grid(row=1,column=1,columnspan=2,padx=10,pady=10)

    #happy mood
    photo_happy = tk.PhotoImage(file="happy.gif")
    happy = tk.Button(whats_your_mood_frame, compound=tk.TOP, image=photo_happy,text="Happy mood",command=happy_mood)
    happy.grid(row=8, column=2, padx=10, pady=20)
    happy.image = photo_happy


    #sad button
    photo_sad = tk.PhotoImage(file="sad.gif")
    sad = tk.Button(whats_your_mood_frame, compound=tk.TOP, image=photo_sad, text="Sad mood",command=sad_mood)
    sad.grid(row=8, column=4, padx=10, pady=20)
    sad.image = photo_sad

    #anxious mood
    photo_anxious = tk.PhotoImage(file="anxious.gif")
    anxious = tk.Button(whats_your_mood_frame, compound=tk.TOP, image=photo_anxious, text="Anxious mood",command=anxious_me)
    anxious.grid(row=10, column=2, padx=30, pady=20)
    anxious.image = photo_anxious

    #tired mood
    photo_tired = tk.PhotoImage(file="tired.gif")
    tired = tk.Button(whats_your_mood_frame, compound=tk.TOP, image=photo_tired, text="Tired mood",command=tired_func)
    tired.grid(row=10, column=4, padx=30, pady=20)
    tired.image = photo_tired






label = Label(fst_frame,text="Hellooo Ok so do you wanna ",font=('Times New Roman',14,'italic'),anchor='center',bg="bisque")
label.grid(row=2,column=3)



photo2 = tk.PhotoImage(file="change mood.gif")
# create the image button, image is above (top) the optional text
button2 = tk.Button(fst_frame, compound=tk.RIGHT,  image=photo2,command=whats_your_mood)
button2.grid( row=8, column=6,padx=10,pady=20)
button2.image = photo2

# main gane start here
#first page




# animation welcome window
animation = pyglet.image.load_animation('welcome.gif')
animSprite = pyglet.sprite.Sprite(animation)

w = animSprite.width
h = animSprite.height

window = pyglet.window.Window(width=w, height=h)
label = pyglet.text.Label("Click ANYWHERE to start",
                          font_name='Times New Roman',
                          font_size=25,
                          x=window.width /10, y = window.height/10,
                          )
r,g,b,alpha = 0.5,0.5,0.8,0.5


pyglet.gl.glClearColor(r,g,b,alpha)


@window.event
def on_draw():
    window.clear()
    animSprite.draw()
    label.draw()

@window.event
def on_mouse_press(x, y, button, modifiers):
    if button == mouse.LEFT:
        window.close()
    if button == mouse.RIGHT :
        window.close()

pyglet.app.run()

root.mainloop()